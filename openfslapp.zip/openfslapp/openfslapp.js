import { LightningElement } from 'lwc';

import { NavigationMixin } from 'lightning/navigation';


export default class Openfslapp extends LightningElement {
      // Navigation to web page 
    navigateToWebPage() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "com.salesforce.fieldservice://v1/sObject/"
            }
        });
    } 
}