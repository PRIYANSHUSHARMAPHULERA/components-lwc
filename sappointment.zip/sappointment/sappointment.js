import { LightningElement,api } from 'lwc';
import main from '@salesforce/apex/appointment.main';
import main1 from '@salesforce/apex/appointment.main1';
import main3 from '@salesforce/apex/appointment.main3';

export default class Sappointment extends LightningElement {
    value;
    value1;
    data;
    Subject1;
    Worktype;
    value3='3'
    @api recordId;
    check=false
    connectedCallback(){
        main().then(result=>{this.data

            var arr=[];
            for(let i=0;i<result.length;i++) {
                arr.push({label: result[i].AppointmentNumber ,value:result[i].Id});
            }
            this.records=arr;
        }    )
    }
    
    get options() {
        return [
            { label: 'Cancel', value: 'cancel' },
            { label: 'Reschedule', value: 'reschedule' }
            
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
        if(this.value==='reschedule'){
            this.check=true;
        }else{
            main3({i:this.recordId})
            .then(result=>{
                console.log('complete');
                this.check=false;
            })
        }

    }
    
    get options1() {
        return [
            { label: 'Leave', value: 'leave' },
            { label: 'not enough tools', value: 'not enough tools' }
            
        ];
    }

    handleChange1(event) {
        this.value1 = event.detail.value;
    }

    handleclick(){
        var fdate=this.template.querySelector('[data-id=schestart]').value;
        var edate=this.template.querySelector('[data-id=scheend]').value;
        console.log(fdate);
        console.log(typeof(fdate));
        main1({i:this.recordId,d1:fdate,d2:edate})
        .then(result=>{
            console.log('done');
        })
    }

    handleChange2(event){
     this.recordId=this.template.querySelector('.so').value;
    //  console.log(this.template.querySelector('.so').value);
     main({s:this.recordId})
     .then(result=>{
         this.data=result;
         this.Subject1=result.Subject;
         this.Worktype=result.WorkType.Name;
         console.log(result);
         console.log(this.data);
     })
    }
}