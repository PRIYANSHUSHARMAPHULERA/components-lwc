import { LightningElement ,api, wire} from 'lwc';
import main from '@salesforce/apex/royal1.main';
import main1 from '@salesforce/apex/royal2.main1';


export default class Slot1 extends LightningElement {
    @api recordId;
    @api userId;
    data=[];
    check;
    start;
    end;
    take=false;

    resourceId;

    @wire(main,{io:'$recordId'})
    m({ error, data }){
        if(data){
            console.log(data);
            this.resourceId = data[1];
            this.data=JSON.parse(data[0]);
            this.check = [];
            this.data.forEach(val => {
                this.check.push({
                    'label': val.Interval.Start + ' - ' + val.Interval.Finish,
                    'value': val.Interval.Start + '|' + val.Interval.Finish
                })
            })
            console.log(this.data, this.check);
        }
        else if(error){
            console.log(error);
        }
    }

    handleChange(event) {
        let chosen = event.target.value.split('|');
        let start = chosen[0];
        let end = chosen[1];
        this.start = start;
        this.end = end;
        console.log(start, end)

    }
    handle(){
        main1({i:this.recordId,d1:this.start,d2:this.end,gd:this.resourceId})
        .then(result=>{
            window.alert('done');
        })
        
    }
    applydate(){
        this.take=true;
    }
    


    
}


